import json
from urllib.request import Request, urlopen

URL = "http://127.0.0.1:8000/api/action"


def test_action(agent, action):
    data = json.dumps({
        "agent": agent,
        "action": action
    }).encode("utf-8")

    request = Request(
        URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )

    with urlopen(request) as response:
        result = json.loads(response.read().decode("utf-8"))

    print(f"\nAgent: {agent}")
    print(f"Action: {action}")
    print(f"Decision: {result['decision']}")
    print(f"Reason: {result['reason']}")


test_action("research", "search_web")
test_action("research", "fake_password_vault")
test_action("coding", "code_review")
test_action("coding", "delete_project")
test_action("email", "draft_email")