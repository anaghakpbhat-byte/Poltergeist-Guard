from http.server import BaseHTTPRequestHandler, HTTPServer
import ast
import json
import threading
from datetime import datetime
from pathlib import Path


HOST = "127.0.0.1"
PORT = 8000

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"


# ============================================================
# SAFE ACTIONS
# ============================================================

SAFE_ACTIONS = {
    "research": [
        "search_web",
        "read_public_article",
        "summarize_text",
    ],

    "coding": [
        "code_review",
        "read_project_file",
        "run_safe_test",
    ],

    "email": [
        "analyze_email",
        "read_mock_email",
        "summarize_inbox",
    ],

    "general": [
        "search_web",
        "read_public_article",
        "summarize_text",
    ],
}


# ============================================================
# DECOY ACTIONS
# ============================================================

DECOY_ACTIONS = {
    "research": [
        "fake_password_vault",
        "fake_admin_export",
    ],

    "coding": [
        "fake_api_keys",
        "fake_admin_console",
    ],

    "email": [
        "fake_confidential_email",
        "fake_payroll",
    ],

    "general": [
        "fake_secret_notes",
        "fake_admin_export",
    ],
}


# ============================================================
# CURRENT POLICIES
# ============================================================

policies = {
    agent: list(actions)
    for agent, actions in SAFE_ACTIONS.items()
}


# ============================================================
# EVENT STORAGE
# ============================================================

events = []
lock = threading.Lock()


# ============================================================
# PYTHON CODE ANALYZER
# ============================================================

def analyze_python_code(code):
    """
    Safely inspect Python syntax without executing the code.

    This uses Python's AST parser only.
    The submitted code is NEVER executed.
    """

    code = str(code or "")

    if not code.strip():
        return {
            "is_python": False,
            "valid": False,
            "status": "NO_CODE",
            "message": "No Python code was supplied.",
        }

    try:
        tree = ast.parse(code)

        return {
            "is_python": True,
            "valid": True,
            "status": "VALID",
            "message": "Python syntax is valid.",
            "line_count": len(code.splitlines()),
            "node_count": sum(
                1 for _ in ast.walk(tree)
            ),
        }

    except SyntaxError as error:
        return {
            "is_python": True,
            "valid": False,
            "status": "SYNTAX_ERROR",
            "message": (
                f"Python syntax error on line "
                f"{error.lineno}: {error.msg}"
            ),
            "line": error.lineno,
            "offset": error.offset,
        }

    except Exception as error:
        return {
            "is_python": True,
            "valid": False,
            "status": "ANALYSIS_ERROR",
            "message": (
                "The code could not be analyzed safely: "
                + str(error)
            ),
        }


# ============================================================
# ACTION CHECK
# ============================================================

def check_action(agent_type, action, code=None):
    """Check a simulated action against the current policy."""

    agent = str(agent_type).lower().strip()
    action = str(action).strip()

    code_analysis = None

    with lock:

        # ----------------------------------------------------
        # UNKNOWN AGENT
        # ----------------------------------------------------

        if agent not in SAFE_ACTIONS:
            decision = "BLOCKED"
            reason = "Unknown agent. Access denied."
            category = "POLICY"
            severity = "HIGH"

        # ----------------------------------------------------
        # DECOY
        # ----------------------------------------------------

        elif action in DECOY_ACTIONS[agent]:
            decision = "BLOCKED"
            reason = "Decoy detected. Access denied."
            category = "DECOY"
            severity = "CRITICAL"

        # ----------------------------------------------------
        # ALLOWED ACTION
        # ----------------------------------------------------

        elif action in policies[agent]:
            decision = "ALLOWED"
            reason = (
                "Action is permitted by the current "
                "agent policy."
            )
            category = "NORMAL"
            severity = "LOW"

            # ------------------------------------------------
            # SPECIAL CODING ANALYSIS
            # ------------------------------------------------

            if action == "code_review" and code:
                code_analysis = analyze_python_code(code)

                if code_analysis["status"] == "VALID":
                    reason = (
                        "Python code was parsed successfully. "
                        "The coding agent may safely review it "
                        "without modifying files."
                    )

                elif code_analysis["status"] == "SYNTAX_ERROR":
                    reason = (
                        "Python syntax issues were detected. "
                        "Reviewing the code is still permitted "
                        "because no files are modified."
                    )

                else:
                    reason = (
                        "The coding action is permitted, but "
                        "the supplied code could not be fully "
                        "analyzed."
                    )

        # ----------------------------------------------------
        # POLICY VIOLATION
        # ----------------------------------------------------

        else:
            decision = "BLOCKED"
            reason = (
                "Action is not permitted by the current "
                "agent policy."
            )
            category = "POLICY"
            severity = "HIGH"

        event = {
            "time": datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
            "agent": agent,
            "action": action,
            "decision": decision,
            "reason": reason,
            "category": category,
            "severity": severity,
        }

        if code_analysis is not None:
            event["code_analysis"] = code_analysis

        events.append(event)

    return event


# ============================================================
# STATUS
# ============================================================

def get_status():

    with lock:
        saved_events = list(events)

    return {
        "events": saved_events,

        "total": len(saved_events),

        "allowed": sum(
            e["decision"] == "ALLOWED"
            for e in saved_events
        ),

        "blocked": sum(
            e["decision"] == "BLOCKED"
            for e in saved_events
        ),

        "decoy_hits": sum(
            e["category"] == "DECOY"
            for e in saved_events
        ),

        "high_severity": sum(
            e["severity"] == "HIGH"
            for e in saved_events
        ),

        "critical_severity": sum(
            e["severity"] == "CRITICAL"
            for e in saved_events
        ),
    }


# ============================================================
# INCIDENT INVESTIGATION
# ============================================================

def investigate_event(event, event_number):

    category = event.get(
        "category",
        "POLICY"
    )

    decision = event.get(
        "decision",
        "BLOCKED"
    )

    severity = event.get(
        "severity",
        "HIGH"
    )

    action = event.get(
        "action",
        "unknown_action"
    )

    agent = event.get(
        "agent",
        "unknown"
    )

    reason = event.get(
        "reason",
        "No reason recorded."
    )

    if category == "DECOY":

        incident_type = "Decoy Resource Access"

        explanation = (
            f"The action '{action}' matched a "
            "configured decoy resource and was "
            "blocked by the guard."
        )

        recommendation = (
            "Review this event and related activity. "
            "Check whether the action was expected "
            "in the simulated scenario."
        )

    elif agent not in SAFE_ACTIONS:

        incident_type = "Unknown Agent"

        explanation = (
            "The request used an agent name that is "
            "not registered in the guard's configured "
            "agent list."
        )

        recommendation = (
            "Verify the agent identifier and check "
            "whether the request came from an "
            "expected test."
        )

    elif decision == "BLOCKED":

        incident_type = "Policy Violation"

        explanation = (
            f"The action '{action}' was not permitted "
            "by the agent's current policy."
        )

        recommendation = (
            "Review the agent's permissions and "
            "determine whether the action should "
            "remain prohibited."
        )

    else:

        incident_type = "Recorded Allowed Action"

        explanation = (
            "The action was allowed under the "
            "current policy. This record is included "
            "for investigation context."
        )

        recommendation = (
            "No immediate action is indicated by "
            "this rule result."
        )

    result = {
        "event_number": event_number,
        "time": event.get("time"),
        "agent": agent,
        "action": action,
        "decision": decision,
        "category": category,
        "severity": severity,
        "reason": reason,
        "incident_type": incident_type,
        "explanation": explanation,
        "recommended_step": recommendation,
    }

    if "code_analysis" in event:
        result["code_analysis"] = event["code_analysis"]

    return result


def get_incidents():

    with lock:
        saved_events = list(events)

    incidents = [
        investigate_event(event, index)
        for index, event in enumerate(
            saved_events,
            start=1
        )
        if event.get("decision") == "BLOCKED"
    ]

    incidents.reverse()

    return {
        "total_incidents": len(incidents),

        "critical_incidents": sum(
            incident["severity"] == "CRITICAL"
            for incident in incidents
        ),

        "high_incidents": sum(
            incident["severity"] == "HIGH"
            for incident in incidents
        ),

        "incidents": incidents,

        "notice": (
            "Findings are generated from simulated "
            "events and predefined rules. A decoy "
            "hit is a warning signal, not proof of "
            "malicious intent."
        ),
    }


# ============================================================
# HTTP SERVER
# ============================================================

class GuardHandler(BaseHTTPRequestHandler):

    def send_json(self, data, status=200):

        body = json.dumps(
            data,
            indent=2
        ).encode("utf-8")

        self.send_response(status)

        self.send_header(
            "Content-Type",
            "application/json"
        )

        self.send_header(
            "Content-Length",
            str(len(body))
        )

        self.send_header(
            "Cache-Control",
            "no-store"
        )

        self.end_headers()

        self.wfile.write(body)


    def read_json(self):

        try:

            length = int(
                self.headers.get(
                    "Content-Length",
                    "0"
                )
            )

            if length <= 0 or length > 100_000:
                return None

            raw = self.rfile.read(length)

            return json.loads(
                raw.decode("utf-8")
            )

        except (
            ValueError,
            UnicodeDecodeError,
            json.JSONDecodeError,
        ):
            return None


    # ========================================================
    # GET
    # ========================================================

    def do_GET(self):

        path = self.path.split("?")[0]

        if path == "/":

            index_file = (
                WEB_DIR / "index.html"
            )

            if not index_file.is_file():

                self.send_error(
                    404,
                    "Dashboard file not found"
                )

                return

            body = index_file.read_bytes()

            self.send_response(200)

            self.send_header(
                "Content-Type",
                "text/html; charset=utf-8"
            )

            self.send_header(
                "Content-Length",
                str(len(body))
            )

            self.send_header(
                "Cache-Control",
                "no-store"
            )

            self.end_headers()

            self.wfile.write(body)

        elif path == "/api/status":

            self.send_json(
                get_status()
            )

        elif path == "/api/incidents":

            self.send_json(
                get_incidents()
            )

        elif path == "/api/policies":

            with lock:

                current = {
                    agent: list(actions)
                    for agent, actions
                    in policies.items()
                }

            self.send_json({
                "policies": current,
                "available_actions": SAFE_ACTIONS,
                "decoy_actions": DECOY_ACTIONS,
            })

        else:

            self.send_error(
                404,
                "Not found"
            )


    # ========================================================
    # POST
    # ========================================================

    def do_POST(self):

        path = self.path.split("?")[0]

        data = self.read_json()

        if data is None:

            self.send_json(
                {
                    "error":
                    "Invalid or missing JSON request body."
                },
                400,
            )

            return


        # ====================================================
        # ACTION
        # ====================================================

        if path == "/api/action":

            agent = data.get("agent")
            action = data.get("action")
            code = data.get("code")

            if (
                not isinstance(agent, str)
                or not isinstance(action, str)
            ):

                self.send_json(
                    {
                        "error":
                        "Agent and action must be text."
                    },
                    400,
                )

                return

            if code is not None and not isinstance(
                code,
                str
            ):

                self.send_json(
                    {
                        "error":
                        "Code must be text."
                    },
                    400,
                )

                return

            event = check_action(
                agent,
                action,
                code
            )

            self.send_json(event)

            return


        # ====================================================
        # POLICY
        # ====================================================

        if path == "/api/policies":

            agent = data.get("agent")
            actions = data.get("actions")

            if (
                not isinstance(agent, str)
                or agent not in SAFE_ACTIONS
            ):

                self.send_json(
                    {"error": "Unknown agent."},
                    400,
                )

                return

            if not isinstance(actions, list):

                self.send_json(
                    {
                        "error":
                        "Actions must be a list."
                    },
                    400,
                )

                return

            if not all(
                isinstance(a, str)
                for a in actions
            ):

                self.send_json(
                    {
                        "error":
                        "Every action must be text."
                    },
                    400,
                )

                return

            allowed_choices = SAFE_ACTIONS[agent]

            if len(actions) != len(set(actions)):

                self.send_json(
                    {
                        "error":
                        "Duplicate actions are not allowed."
                    },
                    400,
                )

                return

            if any(
                action not in allowed_choices
                for action in actions
            ):

                self.send_json(
                    {
                        "error":
                        "Unknown or unsafe permission requested."
                    },
                    400,
                )

                return

            with lock:

                policies[agent] = list(actions)

            self.send_json({
                "success": True,
                "agent": agent,
                "actions": list(actions),
                "message":
                    "Agent policy updated successfully.",
            })

            return


        self.send_error(
            404,
            "Not found"
        )


    def log_message(
        self,
        format_string,
        *args
    ):

        print(
            "[HTTP]",
            format_string % args
        )


# ============================================================
# START SERVER
# ============================================================

if __name__ == "__main__":

    print("=" * 45)
    print("POLTERGEIST GUARD")
    print("Security server starting...")
    print(
        f"Open http://{HOST}:{PORT} "
        "in your browser"
    )
    print(
        "Python code analysis is enabled."
    )
    print(
        "Submitted code is parsed but NEVER executed."
    )
    print(
        "Only simulated actions are checked."
    )
    print(
        "Editable agent policies are enabled."
    )
    print(
        "Incident investigation API is enabled."
    )
    print("=" * 45)

    server = HTTPServer(
        (HOST, PORT),
        GuardHandler
    )

    try:

        server.serve_forever()

    except KeyboardInterrupt:

        print(
            "\nShutting down Poltergeist Guard..."
        )

    finally:

        server.server_close()